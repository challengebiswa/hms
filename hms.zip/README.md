Specialist details url with sample data
we are using h2 database

http://localhost:8001/hmservice/hms/specialistDetails?hospitalName=XYZ&specialistType=Dentist

Appoinement details url with sample data

http://localhost:8001/hmservice/hms/appointmentDetails?appointmentDay=monday&patientName=aaa&specialistName=Edward

Bed details url with sample data

http://localhost:8001/hmservice/hms/bedDetails?hospitalName=XYZ
