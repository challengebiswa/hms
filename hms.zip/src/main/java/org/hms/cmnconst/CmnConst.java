package org.hms.cmnconst;

public class CmnConst {

	public static String HOSPITAL_NOT_FOUND="Hospital Details Not found";
	public static String SPECIALIST_NOT_FOUND="Specialist Details Not found";
	public static String APPOINTMENT_DAY_NOT_FOUND="Appointment Day Not found";
	public static String DISCHARGE="DISCHARGE";
	public static String BEDS_NOT_AVAILABLE="Beds are not available";
}
